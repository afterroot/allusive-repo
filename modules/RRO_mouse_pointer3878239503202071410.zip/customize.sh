SKIPUNZIP=0

ui_print "****************************************"
ui_print "*     Allusive Mouse RRO Overlay       *"
ui_print "****************************************"
ui_print "- Target: Android System Framework (android)"
ui_print "- Installing RRO overlay to /system/product/overlay and /system/vendor/overlay"

# Set permissions
set_perm_recursive "$MODPATH/system" 0 0 0755 0644

ui_print "- Overlay deployed successfully."
ui_print " "
ui_print "TIP: Connect a mouse to see your new mouse cursor!"
ui_print "****************************************"
